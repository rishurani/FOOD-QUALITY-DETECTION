#!/usr/bin/env python3
"""
Packages FreshVision AI into a clean, distributable ZIP archive.
Excludes virtual environments, pycache, and temporary files.
"""

import os
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
ZIP_NAME = "FreshVision_AI_Food_Quality_System.zip"
ZIP_PATH = BASE_DIR / ZIP_NAME

# Also create a copy on the user's Desktop for immediate access
DESKTOP_DIR = Path(os.path.expanduser("~")) / "Desktop"
DESKTOP_ZIP_PATH = DESKTOP_DIR / ZIP_NAME

EXCLUDE_DIRS = {'.venv', 'venv', 'ENV', 'env', '__pycache__', '.git', '.idea', '.vscode', '.pytest_cache'}
EXCLUDE_EXTS = {'.pyc', '.pyo', '.pyd', '.zip', '.tar', '.gz'}

def should_exclude(rel_path: Path):
    for part in rel_path.parts:
        if part in EXCLUDE_DIRS:
            return True
    if rel_path.suffix.lower() in EXCLUDE_EXTS:
        return True
    return False

def make_archive():
    print(f"Creating project distribution archive: {ZIP_PATH}...")
    file_count = 0
    total_bytes = 0

    with zipfile.ZipFile(ZIP_PATH, 'w', compression=zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(BASE_DIR):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for file in files:
                file_path = Path(root) / file
                rel_path = file_path.relative_to(BASE_DIR)
                
                # Don't add the zip itself or excluded files
                if file == ZIP_NAME or should_exclude(rel_path):
                    continue

                # Add inside a top-level folder 'FreshVision_AI_Food_Quality_System/'
                archive_name = Path("FreshVision_AI_Food_Quality_System") / rel_path
                zipf.write(file_path, arcname=str(archive_name))
                file_count += 1
                total_bytes += file_path.stat().st_size

    size_mb = ZIP_PATH.stat().st_size / (1024 * 1024)
    print(f"Archive created successfully!")
    print(f"  Files packaged: {file_count}")
    print(f"  Uncompressed:   {total_bytes / (1024 * 1024):.2f} MB")
    print(f"  ZIP File Size:  {size_mb:.2f} MB")
    print(f"  Saved to:       {ZIP_PATH}")

    # Copy to Desktop if available
    try:
        if DESKTOP_DIR.exists():
            import shutil
            shutil.copy2(ZIP_PATH, DESKTOP_ZIP_PATH)
            print(f"  Copied to Desktop: {DESKTOP_ZIP_PATH}")
    except Exception as e:
        print(f"  Note: Could not copy to desktop: {e}")

if __name__ == '__main__':
    make_archive()
