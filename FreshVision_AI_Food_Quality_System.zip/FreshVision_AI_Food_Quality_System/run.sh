#!/usr/bin/env bash

echo "================================================================="
echo "  FreshVision AI - Food Quality Detection System"
echo "  B.Tech CSE Capstone Project & Portfolio Showcase"
echo "================================================================="
echo ""

# Check for Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is not installed or not in PATH."
    exit 1
fi

echo "[1/3] Checking dependencies..."
pip3 install -r requirements.txt --quiet

echo ""
echo "[2/3] Initializing FreshVision AI Web Server..."
echo ""
echo "================================================================="
echo "  Server is running! Open your browser and go to:"
echo "  http://127.0.0.1:5000  or  http://localhost:5000"
echo "================================================================="
echo ""
echo "Press CTRL+C to stop the server at any time."
echo ""

python3 app.py
