#!/usr/bin/env python3
"""
FreshVision AI - Unit and Integration Tests
Tests Flask API routes, image upload validation, database operations,
prediction integration, and error handling.
"""

import io
import unittest
from pathlib import Path
from PIL import Image

from food_quality import create_app
from food_quality.config import Config
from food_quality.database import db
from food_quality.models import Analysis

class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    UPLOAD_FOLDER = Config.BASE_DIR / 'uploads_test'
    UNCERTAINTY_THRESHOLD = 0.65

class FoodQualitySystemTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app(TestConfig)
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        TestConfig.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()
        # Clean up test uploads
        if TestConfig.UPLOAD_FOLDER.exists():
            for f in TestConfig.UPLOAD_FOLDER.iterdir():
                if f.is_file():
                    try:
                        f.unlink()
                    except OSError:
                        pass
            try:
                TestConfig.UPLOAD_FOLDER.rmdir()
            except OSError:
                pass

    def create_dummy_image(self, format='JPEG', size=(224, 224), color=(100, 200, 100)):
        """Helper to create an in-memory image for upload testing."""
        file_obj = io.BytesIO()
        img = Image.new('RGB', size, color=color)
        img.save(file_obj, format=format)
        file_obj.seek(0)
        return file_obj

    def test_health_endpoint(self):
        """Test GET /api/health returns valid status and configuration."""
        res = self.client.get('/api/health')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['status'], 'healthy')
        self.assertTrue(data['database_connected'])
        self.assertEqual(data['uncertainty_threshold'], 0.65)

    def test_dashboard_stats_empty(self):
        """Test GET /api/dashboard/stats returns empty state cleanly."""
        res = self.client.get('/api/dashboard/stats')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['total_analyses'], 0)
        self.assertEqual(data['fresh_count'], 0)
        self.assertEqual(data['spoiled_count'], 0)
        self.assertEqual(data['recent_analyses'], [])

    def test_upload_missing_file(self):
        """Test POST /api/predict rejects requests with missing file."""
        res = self.client.post('/api/predict', data={})
        self.assertEqual(res.status_code, 400)
        data = res.get_json()
        self.assertFalse(data['success'])
        self.assertEqual(data['error'], 'Missing file')

    def test_upload_invalid_extension(self):
        """Test POST /api/predict rejects disallowed file formats (e.g. .txt)."""
        data = {
            'image': (io.BytesIO(b"Hello text file"), 'sample.txt')
        }
        res = self.client.post('/api/predict', data=data, content_type='multipart/form-data')
        self.assertEqual(res.status_code, 400)
        json_data = res.get_json()
        self.assertFalse(json_data['success'])
        self.assertIn('Unsupported file format', json_data['message'])

    def test_upload_corrupt_image(self):
        """Test POST /api/predict rejects corrupted image files disguised as images."""
        data = {
            'image': (io.BytesIO(b"fake image binary content that fails header check"), 'spoofed.jpg')
        }
        res = self.client.post('/api/predict', data=data, content_type='multipart/form-data')
        self.assertEqual(res.status_code, 400)
        json_data = res.get_json()
        self.assertFalse(json_data['success'])
        self.assertIn('corrupt', json_data['message'])

    def test_history_crud_flow(self):
        """Test full database lifecycle for analysis records."""
        # Insert test records
        record1 = Analysis(
            image_filename='test_uuid_1.jpg',
            predicted_label='Fresh',
            confidence=0.95,
            is_uncertain=False,
            explanation='High quality test sample',
            model_version='v1.0.0-MobileNetV2'
        )
        record2 = Analysis(
            image_filename='test_uuid_2.jpg',
            predicted_label='Spoiled',
            confidence=0.88,
            is_uncertain=False,
            explanation='Decayed test sample',
            model_version='v1.0.0-MobileNetV2'
        )
        db.session.add_all([record1, record2])
        db.session.commit()

        # Check /api/history
        res = self.client.get('/api/history')
        self.assertEqual(res.status_code, 200)
        hist = res.get_json()
        self.assertEqual(hist['pagination']['total_items'], 2)

        # Check search filter
        res_search = self.client.get('/api/history?search=Fresh')
        self.assertEqual(len(res_search.get_json()['items']), 1)

        # Check delete single
        res_del = self.client.delete(f'/api/history/{record1.id}')
        self.assertEqual(res_del.status_code, 200)
        self.assertEqual(Analysis.query.count(), 1)

        # Check clear all
        res_clear = self.client.delete('/api/history')
        self.assertEqual(res_clear.status_code, 200)
        self.assertEqual(Analysis.query.count(), 0)

    def test_page_renders(self):
        """Test all frontend HTML pages return 200 OK."""
        pages = ['/', '/dashboard', '/analyzer', '/history', '/metrics', '/about']
        for page in pages:
            res = self.client.get(page)
            self.assertEqual(res.status_code, 200, f"Page {page} failed to render.")

if __name__ == '__main__':
    unittest.main(verbosity=2)
