#!/usr/bin/env python3
"""
FreshVision AI - Food Quality Detection System
Application Entry Point
"""
import os
from food_quality import create_app

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() in ('true', '1', 't')
    print("=" * 65)
    print(" FreshVision AI: Food Quality Detection System ")
    print(f" Server starting on http://127.0.0.1:{port}")
    print("=" * 65)
    app.run(host='127.0.0.1', port=port, debug=debug)
