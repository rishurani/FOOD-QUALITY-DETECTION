@echo off
title FreshVision AI - Food Quality Detection System
color 0A

echo =================================================================
echo   FreshVision AI - Food Quality Detection System
echo   B.Tech CSE Capstone Project & Portfolio Showcase
echo =================================================================
echo.

:: Check for Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.10, 3.11, or 3.12 from https://www.python.org/
    pause
    exit /b
)

echo [1/3] Checking dependencies...
pip install -r requirements.txt --quiet

echo.
echo [2/3] Initializing FreshVision AI Web Server...
echo.
echo =================================================================
echo   Server is running! Open your browser and go to:
echo   http://127.0.0.1:5000  or  http://localhost:5000
echo =================================================================
echo.
echo Press CTRL+C to stop the server at any time.
echo.

python app.py
pause
