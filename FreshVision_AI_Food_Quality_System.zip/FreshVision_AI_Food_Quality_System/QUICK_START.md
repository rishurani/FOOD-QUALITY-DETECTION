# FreshVision AI - Quick Start & Submission Guide

This project is a complete, production-ready AI-Based Food Quality Detection System built for a B.Tech Computer Science and Engineering capstone project, portfolio review, and technical demonstrations.

---

## 🚀 How to Run the Project (For the Recipient)

### Option 1: Automatic 1-Click Launch (Windows)
Simply double-click the **`run.bat`** file in this directory.
It will verify dependencies and immediately launch the web server at:
👉 **http://127.0.0.1:5000**

---

### Option 2: Command Line (Windows, macOS, Linux)

1. Open your terminal or PowerShell in this folder.
2. (Recommended) Create and activate a virtual environment:
   ```bash
   # Windows
   python -m venv .venv
   .\.venv\Scripts\activate

   # macOS / Linux
   python3 -m venv .venv
   source .venv/bin/activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the application:
   ```bash
   python app.py
   ```
5. Open your browser and navigate to:
   **http://localhost:5000** (or **http://127.0.0.1:5000**)

---

## 🧪 What You Can Test Immediately

1. **Food Quality Analyzer (`/analyzer`)**:
   - Drag and drop or browse food images (`.jpg`, `.png`, `.webp`).
   - Sample images are already included in the `dataset/test/fresh` and `dataset/test/spoiled` folders for instant testing!
   - View real model predictions, confidence percentages, visual gauge, and feature breakdown.
   - Ambiguous predictions below 65% confidence trigger the *"Uncertain prediction"* safeguard.

2. **Analytics Dashboard (`/dashboard`)**:
   - Live Chart.js donut chart showing Fresh vs Spoiled vs Uncertain ratio.
   - 7-day inspection throughput bar chart.
   - Recent scan table with image thumbnails.

3. **Audit History (`/history`)**:
   - Search by filename or prediction keyword.
   - Filter by freshness category.
   - Delete individual records (safely deletes image files from disk).
   - Clear all history with confirmation modal.

4. **Model Performance & Confusion Matrix (`/metrics`)**:
   - View real held-out test evaluation metrics: Accuracy, Precision, Recall, F1-Score.
   - Interactive training and validation loss/accuracy learning curves.
   - 2×2 Confusion Matrix.

5. **About Page (`/about`)**:
   - Full academic paper write-up: Problem Statement, Transfer Learning with MobileNetV2, Preprocessing Pipeline, Mathematical Formulas, Limitations, and Food Safety Ethics.

---

## 🛠️ Machine Learning Scripts Included

- **`train_model.py`**: Full transfer learning training pipeline using MobileNetV2, data augmentation, early stopping, model checkpointing, and held-out test evaluation.
- **`evaluate_model.py`**: Standalone evaluation script to test the model against test data and generate classification reports.
- **`generate_sample_dataset.py`**: Generates a synthetic balanced seed dataset with realistic surface characteristics for instant offline training.
- **`test_app.py`**: Automated unit and integration test suite covering API routes, database operations, image security validation, and inference.

---

## 🛡️ Important Notice
This project is an educational image classification application designed to estimate **visual surface quality**. Image-based computer vision cannot detect microscopic foodborne pathogens (*Salmonella, Listeria, E. coli*) or chemical residues.
