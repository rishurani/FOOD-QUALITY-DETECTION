# FreshVision AI - Food Quality Detection System Using Deep Learning

FreshVision AI is an end-to-end, deep learning-powered web platform for automated visual food quality inspection. Built with **MobileNetV2 Transfer Learning**, **TensorFlow 2**, **Flask**, **SQLite/SQLAlchemy**, and **Chart.js**, this application enables rapid, accurate, and non-destructive classification of agricultural produce into **Fresh** versus **Spoiled** categories.

Designed as a B.Tech Computer Science and Engineering capstone project, an AI/ML portfolio showcase, and a practical demonstration of computer vision in smart food supply chains.

---

## 1. Project Introduction

Post-harvest produce spoilage accounts for significant agricultural waste worldwide. Manual inspection in processing facilities and distribution warehouses is labor-intensive, error-prone, subjective, and risks physical cross-contamination. 

**FreshVision AI** provides an objective visual assessment system. By fine-tuning a pre-trained convolutional neural network (MobileNetV2) on RGB produce imagery, the system identifies surface decay, microbial blemishes, and enzymatic browning. It provides calibrated confidence scores, flags ambiguous samples below a certainty threshold, logs historical analyses into a relational database, and renders interactive dashboard analytics.

> **Food Safety Disclaimer**: FreshVision AI evaluates **visual freshness indicators** from surface imagery. It cannot detect odorless bacterial toxins (*Salmonella*, *E. coli*, *Listeria*), viral pathogens, or chemical pesticides. It serves an educational and assistive role and is not a substitute for certified laboratory food safety inspection.

---

## 2. Key Features

- **Transfer Learning Inference Engine**: Employs MobileNetV2 pre-trained on ImageNet with custom global average pooling, dropout regularization (0.3), and dense classification heads.
- **Interactive Drag-and-Drop Analyzer**:
  - Instant client-side preview with file format and size validation.
  - Multi-stage loading animation during neural network tensor processing.
  - Dynamic visual confidence gauge and color-coded freshness badges.
  - Natural language explanation of detected visual surface features.
- **Uncertainty Calibration**: Samples with model confidence below the configurable threshold (`UNCERTAINTY_THRESHOLD = 0.65`) are explicitly flagged as *"Uncertain prediction"* with instructions for manual review.
- **Live Quality Analytics Dashboard**:
  - Real-time statistics: Total scanned, fresh count, spoiled count, uncertain count, and average confidence.
  - Chart.js donut chart illustrating prediction distribution.
  - Chart.js stacked bar chart showing 7-day daily activity trends.
  - Recent analysis table with sample thumbnails and status badges.
- **Inspection Audit History**:
  - Paginated audit log of all previous analyses stored in SQLite.
  - Real-time search by filename, prediction, or description.
  - Category filtering (`All`, `Fresh`, `Spoiled`, `Uncertain`).
  - Multi-criteria sorting (Newest, Oldest, Highest Confidence, Lowest Confidence).
  - Individual record deletion and bulk history purge (safely deletes image assets from disk).
- **Held-Out Model Performance Dashboard**:
  - Displays empirical metrics calculated strictly on held-out test datasets.
  - Accuracy, Precision, Recall, F1-Score, and 2&times;2 Confusion Matrix.
  - Interactive training and validation loss and accuracy convergence curves.
  - Shows *"Not evaluated yet"* if training has not been executed, preventing fabricated statistics.
- **Enterprise-Grade Security & Robustness**:
  - Image header validation using Pillow to prevent MIME-type spoofing.
  - UUID-based filename generation to avoid file overwrite and collision.
  - Strict path traversal prevention on image serving and deletion routes.
  - Parameterized database operations through SQLAlchemy ORM.
  - Graceful fallback with clear instructions when model weights have not yet been trained.

---

## 3. System Architecture

```mermaid
flowchart TD
    User["User / Web Browser"] -->|"1. Uploads Image (JPG/PNG/WebP)"| FE["Frontend Interface (HTML5/CSS3/Vanilla JS)"]
    FE -->|"2. POST /api/predict"| REST["Flask REST API (routes.py)"]
    
    subgraph Backend ["Backend Processing Pipeline"]
        REST -->|"3. Header & Size Validation"| Val["Image Validator (validators.py)"]
        Val -->|"4. Save with UUID"| Storage[("Uploads Folder")]
        Val -->|"5. RGB & Normalize [-1, 1]"| Preproc["MobileNetV2 Preprocessor"]
        Preproc -->|"6. 224x224x3 Tensor"| Model["FoodQualityPredictor (Singleton)"]
        Model -->|"7. Raw Logits / Sigmoid"| Inference["MobileNetV2 Inference Engine"]
        Inference -->|"8. Verdict & Confidence"| Calc["Threshold & Certainty Logic"]
        Calc -->|"9. Commit Record"| DB[("SQLite Database (analyses table)")]
    end

    Calc -->|"10. JSON Response"| FE
    DB -->|"11. Stats & History"| REST
```

---

## 4. Technology Stack

| Layer | Technologies |
| :--- | :--- |
| **Frontend** | HTML5, Modern CSS3 (CSS Variables, Grid, Flexbox), Vanilla JavaScript (ES6+), Chart.js |
| **Backend** | Python 3.12, Flask 3.0, Werkzeug, Python-dotenv |
| **Database** | SQLite, Flask-SQLAlchemy (SQLAlchemy 2.0 ORM) |
| **Deep Learning** | TensorFlow 2 / Keras, MobileNetV2 (ImageNet Transfer Learning), NumPy |
| **Image Processing** | Pillow (PIL), Scikit-learn (Evaluation Metrics), Matplotlib |

---

## 5. Prerequisites

- Python 3.10, 3.11, or 3.12
- `pip` package manager
- Git version control
- (Optional) Virtual environment tool (`venv`)

---

## 6. Installation & Setup

### Step 1: Clone the Repository
```bash
git clone https://github.com/your-username/freshvision-ai.git
cd freshvision-ai
```

### Step 2: Create and Activate a Virtual Environment
```bash
# Windows (PowerShell)
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Linux / macOS
python3 -m venv .venv
source .venv/bin/activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables (Optional)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Default parameters in `food_quality/config.py` allow running immediately without manual edits.

---

## 7. Dataset Structure & Preparation

The dataset directory must follow this standard format:

```
dataset/
├── train/
│   ├── fresh/      # Fresh produce training images
│   └── spoiled/    # Spoiled produce training images
├── validation/
│   ├── fresh/      # Fresh validation images
│   └── spoiled/    # Spoiled validation images
└── test/
    ├── fresh/      # Held-out test images
    └── spoiled/    # Held-out test images
```

### Quick Start: Generate Built-in Starter Dataset
If you want to train and verify the pipeline immediately without downloading large archives:
```bash
python generate_sample_dataset.py
```
This generates 184 balanced samples across `train`, `validation`, and `test` splits.

### Using Real-World Kaggle Datasets
For production-grade models, download:
- [Kaggle: Fruits Fresh and Rotten for Classification](https://www.kaggle.com/datasets/sriramr/fruits-fresh-and-rotten-for-classification)
- [Kaggle: Fresh and Stale Images of Fruits and Vegetables](https://www.kaggle.com/datasets/raghavrpotdar/fresh-and-stale-images-of-fruits-and-vegetables)

Organize the extracted images into the `dataset/train`, `dataset/validation`, and `dataset/test` folders.

---

## 8. Model Training Pipeline

Execute the automated MobileNetV2 transfer learning pipeline:

```bash
python train_model.py --epochs 15 --fine_tune_epochs 10 --batch_size 32
```

### What this script does:
1. Validates dataset folder hierarchy and image formats.
2. Applies data augmentation (rotations, flips, zoom, contrast) to training images only.
3. Loads MobileNetV2 pre-trained on ImageNet with frozen base layers.
4. Adds GlobalAveragePooling2D, Dropout(0.3), and a Dense(1, sigmoid) classification head.
5. Trains the classification head using Adam optimizer and binary crossentropy.
6. Unfreezes upper layers from layer 100 onwards for fine-tuning at a reduced learning rate (`1e-5`).
7. Employs `EarlyStopping` and `ModelCheckpoint` to save the optimal weights.
8. Evaluates the final model on unseen held-out test data.
9. Computes Test Accuracy, Precision, Recall, F1-Score, and Confusion Matrix.
10. Saves model to `models/food_quality_model.keras` and metrics to `models/model_metrics.json`.
11. Generates convergence plots (`models/training_curves.png`) and confusion matrix visualization (`models/confusion_matrix.png`).

---

## 9. Model Evaluation

To evaluate an existing model checkpoint on the test split:

```bash
python evaluate_model.py --model_path models/food_quality_model.keras --test_dir dataset/test
```

Outputs a full classification report with precision, recall, and harmonic F1-score for each class.

---

## 10. Starting the Web Application

Run the Flask application entry point:

```bash
python app.py
```

Console output:
```
=================================================================
 FreshVision AI: Food Quality Detection System 
 Server starting on http://127.0.0.1:5000
=================================================================
```

Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 11. REST API Documentation

### 1. Health Check
`GET /api/health`
- **Response**:
  ```json
  {
    "status": "healthy",
    "model_loaded": true,
    "model_version": "v1.0.0-MobileNetV2",
    "database_connected": true,
    "total_analyses": 42,
    "uncertainty_threshold": 0.65
  }
  ```

### 2. Predict Food Quality
`POST /api/predict`
- **Request**: `multipart/form-data` with form key `image` containing the image file.
- **Response**:
  ```json
  {
    "success": true,
    "id": 14,
    "prediction": "Fresh",
    "confidence": 0.9652,
    "confidence_percentage": "96.5%",
    "is_uncertain": false,
    "explanation": "Analysis indicates high visual freshness (96.5% confidence)...",
    "image_url": "/uploads/a3b1c9...jpg",
    "timestamp": "2026-10-23T10:00:00Z",
    "model_version": "v1.0.0-MobileNetV2"
  }
  ```

### 3. Get Analysis History
`GET /api/history?page=1&per_page=12&category=all&sort=newest&search=`
- **Response**:
  ```json
  {
    "success": true,
    "items": [...],
    "pagination": {
      "page": 1,
      "per_page": 12,
      "total_items": 42,
      "total_pages": 4,
      "has_next": true,
      "has_prev": false
    }
  }
  ```

### 4. Delete Single Analysis Record
`DELETE /api/history/<id>`
- Deletes record and removes its associated uploaded image file from disk.

### 5. Clear All History
`DELETE /api/history`
- Clears all database records and purges stored image assets.

### 6. Dashboard Analytics
`GET /api/dashboard/stats`
- Returns total counts, category breakdown percentages, average confidence, recent items, and 7-day daily activity arrays.

### 7. Model Evaluation Metrics
`GET /api/model/metrics`
- Returns held-out test evaluation results, training curves, confusion matrix values, and sample split counts.

---

## 12. Project Directory Structure

```
food-quality-system/
├── app.py                      # Flask application entry point
├── train_model.py              # MobileNetV2 training & evaluation pipeline
├── evaluate_model.py           # Standalone model test evaluation script
├── generate_sample_dataset.py  # Seed dataset generator for immediate testing
├── requirements.txt            # Python dependencies
├── .env.example                # Environment variables template
├── .gitignore                  # Git ignore rules
├── README.md                   # Complete documentation
│
├── dataset/                    # Image datasets
│   ├── README.md               # Dataset download & organization guide
│   ├── train/ (fresh, spoiled)
│   ├── validation/ (fresh, spoiled)
│   └── test/ (fresh, spoiled)
│
├── models/                     # Saved artifacts
│   ├── food_quality_model.keras
│   ├── class_indices.json
│   ├── model_metrics.json
│   ├── training_curves.png
│   └── confusion_matrix.png
│
├── uploads/                    # User uploaded images (UUID-named)
├── instance/                   # SQLite database (food_quality.db)
│
├── templates/                  # Jinja2 HTML templates
│   ├── base.html               # Shared layout, navbar, toasts, footer
│   ├── index.html              # Landing page
│   ├── dashboard.html          # Stats, Chart.js donut & bar charts
│   ├── analyzer.html           # Drag & drop upload, inference result
│   ├── history.html            # Paginated audit trail, search, delete
│   ├── model_metrics.html      # Test performance, confusion matrix
│   └── about.html              # Academic paper writeup, methodology
│
├── static/
│   ├── css/
│   │   └── style.css           # Modern agricultural SaaS stylesheet
│   └── js/
│       ├── app.js              # Global toasts, modals, health checker
│       ├── dashboard.js        # Chart.js visualization logic
│       ├── analyzer.js         # Upload & inference handler
│       └── history.js          # Search, filter, pagination, deletion
│
└── food_quality/               # Core Python package
    ├── __init__.py             # Flask application factory
    ├── config.py               # Configuration constants & paths
    ├── database.py             # SQLAlchemy instance
    ├── models.py               # Analysis database ORM model
    ├── predictor.py            # Singleton MobileNetV2 predictor
    ├── routes.py               # UI routes & REST API endpoints
    └── validators.py           # File header & path security validators
```

---

## 13. License & Academic Attribution

Developed as a B.Tech Computer Science and Engineering Capstone Project. Open source under the MIT License.
